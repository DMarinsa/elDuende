"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Rol = /** @class */ (function () {
    function Rol() {
    }
    return Rol;
}());
exports.Rol = Rol;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm9sLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicm9sLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0E7SUFBQTtJQUdBLENBQUM7SUFBRCxVQUFDO0FBQUQsQ0FBQyxBQUhELElBR0M7QUFIWSxrQkFBRyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEtpbnZleSB9IGZyb20gJ2tpbnZleS1uYXRpdmVzY3JpcHQtc2RrJztcclxuZXhwb3J0IGNsYXNzIFJvbCBpbXBsZW1lbnRzIEtpbnZleS5FbnRpdHkge1xyXG4gICAgX2lkOiBzdHJpbmdcclxuICAgIG5vbWJyZTogc3RyaW5nXHJcbn0iXX0=