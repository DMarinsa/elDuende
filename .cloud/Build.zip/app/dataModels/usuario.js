"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Usuario = /** @class */ (function () {
    function Usuario(_id, nombre, password, fechaAlta, fechaBaja) {
        this._id = _id;
        this.nombre = nombre;
        this.password = password;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
    }
    return Usuario;
}());
exports.Usuario = Usuario;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXN1YXJpby5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInVzdWFyaW8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDQTtJQUNJLGlCQUNXLEdBQVcsRUFDWCxNQUFjLEVBQ2QsUUFBZ0IsRUFDaEIsU0FBaUIsRUFDakIsU0FBa0I7UUFKbEIsUUFBRyxHQUFILEdBQUcsQ0FBUTtRQUNYLFdBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxhQUFRLEdBQVIsUUFBUSxDQUFRO1FBQ2hCLGNBQVMsR0FBVCxTQUFTLENBQVE7UUFDakIsY0FBUyxHQUFULFNBQVMsQ0FBUztJQUFFLENBQUM7SUFDcEMsY0FBQztBQUFELENBQUMsQUFQRCxJQU9DO0FBUFksMEJBQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBLaW52ZXkgfSBmcm9tICdraW52ZXktbmF0aXZlc2NyaXB0LXNkayc7XHJcbmV4cG9ydCBjbGFzcyBVc3VhcmlvIGltcGxlbWVudHMgS2ludmV5LkVudGl0eSB7XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgX2lkOiBzdHJpbmcsXHJcbiAgICAgICAgcHVibGljIG5vbWJyZTogc3RyaW5nLFxyXG4gICAgICAgIHB1YmxpYyBwYXNzd29yZDogc3RyaW5nLFxyXG4gICAgICAgIHB1YmxpYyBmZWNoYUFsdGE6IHN0cmluZyxcclxuICAgICAgICBwdWJsaWMgZmVjaGFCYWphPzogc3RyaW5nKXt9XHJcbn0iXX0=