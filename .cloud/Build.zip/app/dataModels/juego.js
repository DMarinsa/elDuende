"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Juego = /** @class */ (function () {
    function Juego(_id, titulo, jugadores, disponible, fechaAlta, fechaBaja) {
        this._id = _id;
        this.titulo = titulo;
        this.jugadores = jugadores;
        this.disponible = disponible;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
    }
    return Juego;
}());
exports.Juego = Juego;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianVlZ28uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJqdWVnby50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUNBO0lBQ0ksZUFDVyxHQUFXLEVBQ1gsTUFBYyxFQUNkLFNBQWlCLEVBQ2pCLFVBQW1CLEVBQ25CLFNBQWlCLEVBQ2pCLFNBQWlCO1FBTGpCLFFBQUcsR0FBSCxHQUFHLENBQVE7UUFDWCxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsY0FBUyxHQUFULFNBQVMsQ0FBUTtRQUNqQixlQUFVLEdBQVYsVUFBVSxDQUFTO1FBQ25CLGNBQVMsR0FBVCxTQUFTLENBQVE7UUFDakIsY0FBUyxHQUFULFNBQVMsQ0FBUTtJQUFFLENBQUM7SUFDbkMsWUFBQztBQUFELENBQUMsQUFSRCxJQVFDO0FBUlksc0JBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBLaW52ZXkgfSBmcm9tICdraW52ZXktbmF0aXZlc2NyaXB0LXNkayc7XHJcbmV4cG9ydCBjbGFzcyBKdWVnbyBpbXBsZW1lbnRzIEtpbnZleS5FbnRpdHkge1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHVibGljIF9pZDogc3RyaW5nLFxyXG4gICAgICAgIHB1YmxpYyB0aXR1bG86IHN0cmluZyxcclxuICAgICAgICBwdWJsaWMganVnYWRvcmVzOiBudW1iZXIsXHJcbiAgICAgICAgcHVibGljIGRpc3BvbmlibGU6IGJvb2xlYW4sXHJcbiAgICAgICAgcHVibGljIGZlY2hhQWx0YTogc3RyaW5nLFxyXG4gICAgICAgIHB1YmxpYyBmZWNoYUJhamE6IHN0cmluZyl7fVxyXG59Il19