"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Partida = /** @class */ (function () {
    function Partida(_id, fecha, juego, jugadores, duracion) {
        this._id = _id;
        this.fecha = fecha;
        this.juego = juego;
        this.jugadores = jugadores;
        this.duracion = duracion;
    }
    return Partida;
}());
exports.Partida = Partida;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFydGlkYXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwYXJ0aWRhcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUdBO0lBQ0ksaUJBQ08sR0FBVyxFQUNYLEtBQVcsRUFDWCxLQUFZLEVBQ1osU0FBb0IsRUFDcEIsUUFBaUI7UUFKakIsUUFBRyxHQUFILEdBQUcsQ0FBUTtRQUNYLFVBQUssR0FBTCxLQUFLLENBQU07UUFDWCxVQUFLLEdBQUwsS0FBSyxDQUFPO1FBQ1osY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixhQUFRLEdBQVIsUUFBUSxDQUFTO0lBQUUsQ0FBQztJQUMvQixjQUFDO0FBQUQsQ0FBQyxBQVBELElBT0M7QUFQWSwwQkFBTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEtpbnZleSB9IGZyb20gJ2tpbnZleS1uYXRpdmVzY3JpcHQtc2RrJztcclxuaW1wb3J0IHsgSnVlZ28gfSBmcm9tICd+L2RhdGFNb2RlbHMvanVlZ28nO1xyXG5pbXBvcnQgeyBVc3VhcmlvIH0gZnJvbSAnfi9kYXRhTW9kZWxzL3VzdWFyaW8nO1xyXG5leHBvcnQgY2xhc3MgUGFydGlkYSBpbXBsZW1lbnRzIEtpbnZleS5FbnRpdHkge1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICBwdWJsaWMgX2lkOiBzdHJpbmcsXHJcbiAgICBwdWJsaWMgZmVjaGE6IERhdGUsXHJcbiAgICBwdWJsaWMganVlZ286IEp1ZWdvLFxyXG4gICAgcHVibGljIGp1Z2Fkb3JlczogW1VzdWFyaW9dLFxyXG4gICAgcHVibGljIGR1cmFjaW9uPzogbnVtYmVyKXt9XHJcbn0iXX0=