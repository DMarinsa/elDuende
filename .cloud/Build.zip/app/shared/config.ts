export class Config {
    static kinveyAppKey = "kid_rJLHYj4y7";
    static kinveyAppSecret = "bf91817c9ce44b15a2b9495680819cb3";
    static kinveyUsername = "admin";
    static kinveyPassword = "admin";
}
