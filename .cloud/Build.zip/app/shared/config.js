"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = /** @class */ (function () {
    function Config() {
    }
    Config.kinveyAppKey = "kid_rJLHYj4y7";
    Config.kinveyAppSecret = "bf91817c9ce44b15a2b9495680819cb3";
    Config.kinveyUsername = "admin";
    Config.kinveyPassword = "admin";
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7SUFBQTtJQUtBLENBQUM7SUFKVSxtQkFBWSxHQUFHLGVBQWUsQ0FBQztJQUMvQixzQkFBZSxHQUFHLGtDQUFrQyxDQUFDO0lBQ3JELHFCQUFjLEdBQUcsT0FBTyxDQUFDO0lBQ3pCLHFCQUFjLEdBQUcsT0FBTyxDQUFDO0lBQ3BDLGFBQUM7Q0FBQSxBQUxELElBS0M7QUFMWSx3QkFBTSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBDb25maWcge1xyXG4gICAgc3RhdGljIGtpbnZleUFwcEtleSA9IFwia2lkX3JKTEhZajR5N1wiO1xyXG4gICAgc3RhdGljIGtpbnZleUFwcFNlY3JldCA9IFwiYmY5MTgxN2M5Y2U0NGIxNWEyYjk0OTU2ODA4MTljYjNcIjtcclxuICAgIHN0YXRpYyBraW52ZXlVc2VybmFtZSA9IFwiYWRtaW5cIjtcclxuICAgIHN0YXRpYyBraW52ZXlQYXNzd29yZCA9IFwiYWRtaW5cIjtcclxufVxyXG4iXX0=