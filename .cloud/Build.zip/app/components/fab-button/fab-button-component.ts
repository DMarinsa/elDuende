import { EventData } from 'data/observable'

// http://moduscreate.com/custom-components-in-nativescript/

export function onLoaded(args: EventData) {
	var label = args.object;
}