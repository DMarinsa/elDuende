"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var forgottenPassword_component_1 = require("./forgottenPassword.component");
var routes = [
    { path: "", component: forgottenPassword_component_1.ForgottenPasswordComponent }
];
var ForgottenPasswordRoutingModule = /** @class */ (function () {
    function ForgottenPasswordRoutingModule() {
    }
    ForgottenPasswordRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forChild(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], ForgottenPasswordRoutingModule);
    return ForgottenPasswordRoutingModule;
}());
exports.ForgottenPasswordRoutingModule = ForgottenPasswordRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9yZ290dGVuUGFzc3dvcmQtcm91dGluZy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJmb3Jnb3R0ZW5QYXNzd29yZC1yb3V0aW5nLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5QztBQUV6QyxzREFBdUU7QUFFdkUsNkVBQTJFO0FBRTNFLElBQU0sTUFBTSxHQUFXO0lBQ25CLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsd0RBQTBCLEVBQUU7Q0FDdEQsQ0FBQztBQU1GO0lBQUE7SUFBOEMsQ0FBQztJQUFsQyw4QkFBOEI7UUFKMUMsZUFBUSxDQUFDO1lBQ04sT0FBTyxFQUFFLENBQUMsaUNBQXdCLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3BELE9BQU8sRUFBRSxDQUFDLGlDQUF3QixDQUFDO1NBQ3RDLENBQUM7T0FDVyw4QkFBOEIsQ0FBSTtJQUFELHFDQUFDO0NBQUEsQUFBL0MsSUFBK0M7QUFBbEMsd0VBQThCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgUm91dGVzIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL3JvdXRlclwiO1xuXG5pbXBvcnQgeyBGb3Jnb3R0ZW5QYXNzd29yZENvbXBvbmVudCB9IGZyb20gXCIuL2ZvcmdvdHRlblBhc3N3b3JkLmNvbXBvbmVudFwiO1xuXG5jb25zdCByb3V0ZXM6IFJvdXRlcyA9IFtcbiAgICB7IHBhdGg6IFwiXCIsIGNvbXBvbmVudDogRm9yZ290dGVuUGFzc3dvcmRDb21wb25lbnQgfVxuXTtcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLmZvckNoaWxkKHJvdXRlcyldLFxuICAgIGV4cG9ydHM6IFtOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGVdXG59KVxuZXhwb3J0IGNsYXNzIEZvcmdvdHRlblBhc3N3b3JkUm91dGluZ01vZHVsZSB7IH1cbiJdfQ==