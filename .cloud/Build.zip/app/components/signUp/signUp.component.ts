import { Component, OnInit } from "@angular/core";
import { HttpClient } from '@angular/common/http'
import { Usuario } from "~/dataModels/usuario";

/* ***********************************************************
* Before you can navigate to this page from your app, you need to reference this page's module in the
* global app router module. Add the following object to the global array of routes:
* { path: "signUp", loadChildren: "./signUp/signUp.module#SignUpModule" }
* Note that this simply points the path to the page module file. If you move the page, you need to update the route too.
*************************************************************/

@Component({
    selector: "SignUp",
    moduleId: module.id,
    templateUrl: "./signUp.component.html"
})
export class SignUpComponent implements OnInit {
    name: string;
    email: string;
    password: string;
    repeat: string;

    constructor(public http: HttpClient) {
    }

    ngOnInit(): void {
    }

    onSignupWithSocialProviderButtonTap(): void {
        /* ***********************************************************
        * For sign up with social provider you can add your custom logic or
        * use NativeScript plugin for sign up with Facebook
        * http://market.nativescript.org/plugins/nativescript-facebook
        *************************************************************/
    }

    async onSignupButtonTap(): Promise<void> {
        const name = this.name;
        const email = this.email;
        const password = this.password;
        const repeat = this.repeat;
        const fecha = new Date().toLocaleDateString();
        if(password===repeat){
            const user = new Usuario(email,name, password, fecha);
            try{
                await this.http.post<Usuario>('/appdata/kid_rJLHYj4y7/Usuarios', user);
            } catch(err){
                console.log(err);
            }
        }
    }
}
