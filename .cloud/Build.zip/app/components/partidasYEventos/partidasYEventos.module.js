"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var partidasYEventos_routing_module_1 = require("./partidasYEventos-routing.module");
var partidasYEventos_component_1 = require("./partidasYEventos.component");
var PartidasYEventosModule = /** @class */ (function () {
    function PartidasYEventosModule() {
    }
    PartidasYEventosModule = __decorate([
        core_1.NgModule({
            imports: [
                nativescript_module_1.NativeScriptModule,
                partidasYEventos_routing_module_1.PartidasYEventosRoutingModule
            ],
            declarations: [
                partidasYEventos_component_1.PartidasYEventosComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], PartidasYEventosModule);
    return PartidasYEventosModule;
}());
exports.PartidasYEventosModule = PartidasYEventosModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFydGlkYXNZRXZlbnRvcy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwYXJ0aWRhc1lFdmVudG9zLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyRDtBQUMzRCxnRkFBOEU7QUFFOUUscUZBQWtGO0FBQ2xGLDJFQUF5RTtBQWN6RTtJQUFBO0lBQXNDLENBQUM7SUFBMUIsc0JBQXNCO1FBWmxDLGVBQVEsQ0FBQztZQUNOLE9BQU8sRUFBRTtnQkFDTCx3Q0FBa0I7Z0JBQ2xCLCtEQUE2QjthQUNoQztZQUNELFlBQVksRUFBRTtnQkFDVixzREFBeUI7YUFDNUI7WUFDRCxPQUFPLEVBQUU7Z0JBQ0wsdUJBQWdCO2FBQ25CO1NBQ0osQ0FBQztPQUNXLHNCQUFzQixDQUFJO0lBQUQsNkJBQUM7Q0FBQSxBQUF2QyxJQUF1QztBQUExQix3REFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSwgTk9fRVJST1JTX1NDSEVNQSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRNb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvbmF0aXZlc2NyaXB0Lm1vZHVsZVwiO1xuXG5pbXBvcnQgeyBQYXJ0aWRhc1lFdmVudG9zUm91dGluZ01vZHVsZSB9IGZyb20gXCIuL3BhcnRpZGFzWUV2ZW50b3Mtcm91dGluZy5tb2R1bGVcIjtcbmltcG9ydCB7IFBhcnRpZGFzWUV2ZW50b3NDb21wb25lbnQgfSBmcm9tIFwiLi9wYXJ0aWRhc1lFdmVudG9zLmNvbXBvbmVudFwiO1xuXG5ATmdNb2R1bGUoe1xuICAgIGltcG9ydHM6IFtcbiAgICAgICAgTmF0aXZlU2NyaXB0TW9kdWxlLFxuICAgICAgICBQYXJ0aWRhc1lFdmVudG9zUm91dGluZ01vZHVsZVxuICAgIF0sXG4gICAgZGVjbGFyYXRpb25zOiBbXG4gICAgICAgIFBhcnRpZGFzWUV2ZW50b3NDb21wb25lbnRcbiAgICBdLFxuICAgIHNjaGVtYXM6IFtcbiAgICAgICAgTk9fRVJST1JTX1NDSEVNQVxuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgUGFydGlkYXNZRXZlbnRvc01vZHVsZSB7IH1cbiJdfQ==