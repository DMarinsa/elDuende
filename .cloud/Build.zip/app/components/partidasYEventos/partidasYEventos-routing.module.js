"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var partidasYEventos_component_1 = require("./partidasYEventos.component");
var routes = [
    { path: "", component: partidasYEventos_component_1.PartidasYEventosComponent }
];
var PartidasYEventosRoutingModule = /** @class */ (function () {
    function PartidasYEventosRoutingModule() {
    }
    PartidasYEventosRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forChild(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], PartidasYEventosRoutingModule);
    return PartidasYEventosRoutingModule;
}());
exports.PartidasYEventosRoutingModule = PartidasYEventosRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFydGlkYXNZRXZlbnRvcy1yb3V0aW5nLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInBhcnRpZGFzWUV2ZW50b3Mtcm91dGluZy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBeUM7QUFFekMsc0RBQXVFO0FBRXZFLDJFQUF5RTtBQUV6RSxJQUFNLE1BQU0sR0FBVztJQUNuQixFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLHNEQUF5QixFQUFFO0NBQ3JELENBQUM7QUFNRjtJQUFBO0lBQTZDLENBQUM7SUFBakMsNkJBQTZCO1FBSnpDLGVBQVEsQ0FBQztZQUNOLE9BQU8sRUFBRSxDQUFDLGlDQUF3QixDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwRCxPQUFPLEVBQUUsQ0FBQyxpQ0FBd0IsQ0FBQztTQUN0QyxDQUFDO09BQ1csNkJBQTZCLENBQUk7SUFBRCxvQ0FBQztDQUFBLEFBQTlDLElBQThDO0FBQWpDLHNFQUE2QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJvdXRlcyB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcblxuaW1wb3J0IHsgUGFydGlkYXNZRXZlbnRvc0NvbXBvbmVudCB9IGZyb20gXCIuL3BhcnRpZGFzWUV2ZW50b3MuY29tcG9uZW50XCI7XG5cbmNvbnN0IHJvdXRlczogUm91dGVzID0gW1xuICAgIHsgcGF0aDogXCJcIiwgY29tcG9uZW50OiBQYXJ0aWRhc1lFdmVudG9zQ29tcG9uZW50IH1cbl07XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW05hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZS5mb3JDaGlsZChyb3V0ZXMpXSxcbiAgICBleHBvcnRzOiBbTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlXVxufSlcbmV4cG9ydCBjbGFzcyBQYXJ0aWRhc1lFdmVudG9zUm91dGluZ01vZHVsZSB7IH1cbiJdfQ==