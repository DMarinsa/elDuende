"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var login_component_1 = require("~/components/login/login.component");
var home_component_1 = require("~/components/home/home.component");
var signUp_component_1 = require("~/components/signUp/signUp.component");
var perfil_component_1 = require("~/components/perfil/perfil.component");
var partidasYEventos_component_1 = require("~/components/partidasYEventos/partidasYEventos.component");
var Prestamos_component_1 = require("~/components/Prestamos/Prestamos.component");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var forgottenPassword_component_1 = require("~/components/forgottenPassword/forgottenPassword.component");
var Partida_component_1 = require("~/components/Partida/Partida.component");
var juego_component_1 = require("~/components/juego/juego.component");
var routes = [
    { path: "", component: login_component_1.LoginComponent },
    { path: "home", component: home_component_1.HomeComponent },
    { path: "signUp", component: signUp_component_1.SignUpComponent },
    { path: "perfil", component: perfil_component_1.PerfilComponent },
    { path: "partidas", component: partidasYEventos_component_1.PartidasYEventosComponent,
        children: [
            { path: '', redirectTo: 'overview', pathMatch: 'full' },
            { path: 'partida/:id', component: Partida_component_1.PartidaComponent }
        ]
    },
    { path: "prestamos", component: Prestamos_component_1.PrestamosComponent,
        children: [
            { path: '', redirectTo: 'overview', pathMatch: 'full' },
            { path: 'juego/:id', component: juego_component_1.JuegoComponent }
        ]
    },
    { path: "password", component: forgottenPassword_component_1.ForgottenPasswordComponent }
];
exports.navigatableComponents = [
    login_component_1.LoginComponent,
    home_component_1.HomeComponent,
    signUp_component_1.SignUpComponent,
    perfil_component_1.PerfilComponent,
    partidasYEventos_component_1.PartidasYEventosComponent,
    Prestamos_component_1.PrestamosComponent,
    forgottenPassword_component_1.ForgottenPasswordComponent,
    juego_component_1.JuegoComponent,
    Partida_component_1.PartidaComponent
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [
                nativescript_module_1.NativeScriptModule,
                router_1.NativeScriptRouterModule.forRoot(routes)
            ],
            declarations: [
                exports.navigatableComponents
            ],
            bootstrap: [login_component_1.LoginComponent],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLXJvdXRpbmcubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBwLXJvdXRpbmcubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlDO0FBRXpDLHNEQUF1RTtBQUN2RSxzRUFBb0U7QUFDcEUsbUVBQWlFO0FBQ2pFLHlFQUF1RTtBQUN2RSx5RUFBdUU7QUFDdkUsdUdBQXFHO0FBQ3JHLGtGQUFnRjtBQUNoRixnRkFBOEU7QUFDOUUsMEdBQXdHO0FBQ3hHLDRFQUEwRTtBQUMxRSxzRUFBb0U7QUFFcEUsSUFBTSxNQUFNLEdBQVc7SUFDbkIsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLFNBQVMsRUFBRSxnQ0FBYyxFQUFDO0lBQ3RDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsOEJBQWEsRUFBRTtJQUMxQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLGtDQUFlLEVBQUM7SUFDN0MsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxrQ0FBZSxFQUFDO0lBQzdDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsc0RBQXlCO1FBQ3BELFFBQVEsRUFBRTtZQUNOLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUM7WUFDdEQsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxvQ0FBZ0IsRUFBQztTQUN0RDtLQUNKO0lBQ0QsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSx3Q0FBa0I7UUFDOUMsUUFBUSxFQUFFO1lBQ04sRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBQztZQUN0RCxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLGdDQUFjLEVBQUM7U0FDbEQ7S0FDSjtJQUNELEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsd0RBQTBCLEVBQUM7Q0FDN0QsQ0FBQztBQUVXLFFBQUEscUJBQXFCLEdBQUc7SUFDakMsZ0NBQWM7SUFDZCw4QkFBYTtJQUNiLGtDQUFlO0lBQ2Ysa0NBQWU7SUFDZixzREFBeUI7SUFDekIsd0NBQWtCO0lBQ2xCLHdEQUEwQjtJQUMxQixnQ0FBYztJQUNkLG9DQUFnQjtDQUNuQixDQUFDO0FBYUY7SUFBQTtJQUFnQyxDQUFDO0lBQXBCLGdCQUFnQjtRQVg1QixlQUFRLENBQUM7WUFDTixPQUFPLEVBQUU7Z0JBQ0wsd0NBQWtCO2dCQUNsQixpQ0FBd0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2FBQzNDO1lBQ0QsWUFBWSxFQUFFO2dCQUNWLDZCQUFxQjthQUN4QjtZQUNELFNBQVMsRUFBRSxDQUFDLGdDQUFjLENBQUM7WUFDM0IsT0FBTyxFQUFFLENBQUMsaUNBQXdCLENBQUM7U0FDdEMsQ0FBQztPQUNXLGdCQUFnQixDQUFJO0lBQUQsdUJBQUM7Q0FBQSxBQUFqQyxJQUFpQztBQUFwQiw0Q0FBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IFJvdXRlcyB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL3JvdXRlclwiO1xyXG5pbXBvcnQgeyBMb2dpbkNvbXBvbmVudCB9IGZyb20gXCJ+L2NvbXBvbmVudHMvbG9naW4vbG9naW4uY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEhvbWVDb21wb25lbnQgfSBmcm9tIFwifi9jb21wb25lbnRzL2hvbWUvaG9tZS5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgU2lnblVwQ29tcG9uZW50IH0gZnJvbSBcIn4vY29tcG9uZW50cy9zaWduVXAvc2lnblVwLmNvbXBvbmVudFwiO1xyXG5pbXBvcnQgeyBQZXJmaWxDb21wb25lbnQgfSBmcm9tIFwifi9jb21wb25lbnRzL3BlcmZpbC9wZXJmaWwuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IFBhcnRpZGFzWUV2ZW50b3NDb21wb25lbnQgfSBmcm9tIFwifi9jb21wb25lbnRzL3BhcnRpZGFzWUV2ZW50b3MvcGFydGlkYXNZRXZlbnRvcy5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgUHJlc3RhbW9zQ29tcG9uZW50IH0gZnJvbSBcIn4vY29tcG9uZW50cy9QcmVzdGFtb3MvUHJlc3RhbW9zLmNvbXBvbmVudFwiO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRNb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvbmF0aXZlc2NyaXB0Lm1vZHVsZVwiO1xyXG5pbXBvcnQgeyBGb3Jnb3R0ZW5QYXNzd29yZENvbXBvbmVudCB9IGZyb20gXCJ+L2NvbXBvbmVudHMvZm9yZ290dGVuUGFzc3dvcmQvZm9yZ290dGVuUGFzc3dvcmQuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IFBhcnRpZGFDb21wb25lbnQgfSBmcm9tIFwifi9jb21wb25lbnRzL1BhcnRpZGEvUGFydGlkYS5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgSnVlZ29Db21wb25lbnQgfSBmcm9tIFwifi9jb21wb25lbnRzL2p1ZWdvL2p1ZWdvLmNvbXBvbmVudFwiO1xyXG5cclxuY29uc3Qgcm91dGVzOiBSb3V0ZXMgPSBbXHJcbiAgICB7IHBhdGg6IFwiXCIsIGNvbXBvbmVudDogTG9naW5Db21wb25lbnR9LFxyXG4gICAgeyBwYXRoOiBcImhvbWVcIiwgY29tcG9uZW50OiBIb21lQ29tcG9uZW50IH0sXHJcbiAgICB7IHBhdGg6IFwic2lnblVwXCIsIGNvbXBvbmVudDogU2lnblVwQ29tcG9uZW50fSxcclxuICAgIHsgcGF0aDogXCJwZXJmaWxcIiwgY29tcG9uZW50OiBQZXJmaWxDb21wb25lbnR9LFxyXG4gICAgeyBwYXRoOiBcInBhcnRpZGFzXCIsIGNvbXBvbmVudDogUGFydGlkYXNZRXZlbnRvc0NvbXBvbmVudCxcclxuICAgICAgICBjaGlsZHJlbjogW1xyXG4gICAgICAgICAgICB7IHBhdGg6ICcnLCByZWRpcmVjdFRvOiAnb3ZlcnZpZXcnLCBwYXRoTWF0Y2g6ICdmdWxsJ30sXHJcbiAgICAgICAgICAgIHsgcGF0aDogJ3BhcnRpZGEvOmlkJywgY29tcG9uZW50OiBQYXJ0aWRhQ29tcG9uZW50fVxyXG4gICAgICAgIF1cclxuICAgIH0sXHJcbiAgICB7IHBhdGg6IFwicHJlc3RhbW9zXCIsIGNvbXBvbmVudDogUHJlc3RhbW9zQ29tcG9uZW50LFxyXG4gICAgICAgIGNoaWxkcmVuOiBbXHJcbiAgICAgICAgICAgIHsgcGF0aDogJycsIHJlZGlyZWN0VG86ICdvdmVydmlldycsIHBhdGhNYXRjaDogJ2Z1bGwnfSxcclxuICAgICAgICAgICAgeyBwYXRoOiAnanVlZ28vOmlkJywgY29tcG9uZW50OiBKdWVnb0NvbXBvbmVudH1cclxuICAgICAgICBdXHJcbiAgICB9LFxyXG4gICAgeyBwYXRoOiBcInBhc3N3b3JkXCIsIGNvbXBvbmVudDogRm9yZ290dGVuUGFzc3dvcmRDb21wb25lbnR9XHJcbl07XHJcblxyXG5leHBvcnQgY29uc3QgbmF2aWdhdGFibGVDb21wb25lbnRzID0gW1xyXG4gICAgTG9naW5Db21wb25lbnQsXHJcbiAgICBIb21lQ29tcG9uZW50LFxyXG4gICAgU2lnblVwQ29tcG9uZW50LFxyXG4gICAgUGVyZmlsQ29tcG9uZW50LFxyXG4gICAgUGFydGlkYXNZRXZlbnRvc0NvbXBvbmVudCxcclxuICAgIFByZXN0YW1vc0NvbXBvbmVudCxcclxuICAgIEZvcmdvdHRlblBhc3N3b3JkQ29tcG9uZW50LFxyXG4gICAgSnVlZ29Db21wb25lbnQsXHJcbiAgICBQYXJ0aWRhQ29tcG9uZW50XHJcbl07XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gICAgaW1wb3J0czogW1xyXG4gICAgICAgIE5hdGl2ZVNjcmlwdE1vZHVsZSxcclxuICAgICAgICBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUuZm9yUm9vdChyb3V0ZXMpXHJcbiAgICBdLFxyXG4gICAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICAgICAgbmF2aWdhdGFibGVDb21wb25lbnRzXHJcbiAgICBdLFxyXG4gICAgYm9vdHN0cmFwOiBbTG9naW5Db21wb25lbnRdLFxyXG4gICAgZXhwb3J0czogW05hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZV1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFwcFJvdXRpbmdNb2R1bGUgeyB9XHJcbiJdfQ==